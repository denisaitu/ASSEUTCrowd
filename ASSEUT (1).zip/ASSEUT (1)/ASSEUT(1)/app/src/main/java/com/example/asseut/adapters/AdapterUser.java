package com.example.asseut.adapters;

public class AdapterUser {
}
